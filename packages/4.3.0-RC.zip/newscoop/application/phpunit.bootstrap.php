<?php
// Define path to application directory
define('APPLICATION_PATH', __DIR__ . '/../application');

require_once __DIR__.'/autoload.php';
