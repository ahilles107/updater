<?php
require_once($Campsite['HTML_DIR'] . "/$ADMIN_DIR/home.php");
?>
